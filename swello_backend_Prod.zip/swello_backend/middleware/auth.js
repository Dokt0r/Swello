import jwt from "jsonwebtoken";
import config from "../config.js";

const auth = (req, res, next) => {
  const header = req.headers["authorization"];
  if (!header) return res.status(401).json({ error: "No header Authorization" });

  const token = header.split(" ")[1];

  console.log("TOKEN QUE LLEGA:", token);
  console.log("JWT SECRET ACTUAL:", config.jwtSecret);

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    console.log("DECODED OK:", decoded);
    req.userId = decoded.id;
    next();
  } catch (err) {
    console.error("ERROR VERIFICANDO JWT:", err.message);
    return res.status(401).json({ error: "Token inválido" });
  }
};

export default auth;

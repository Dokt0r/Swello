import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import config from "../config.js";
import db from "../database/db.js";

passport.use(
  new GoogleStrategy(
    {
      clientID: config.google.clientID,
      clientSecret: config.google.clientSecret,
      callbackURL: config.google.callbackURL
    },
    (accessToken, refreshToken, profile, done) => {
      const email = profile.emails[0].value;
      const google_id = profile.id;
      const name = profile.displayName;

      db.query("SELECT * FROM users WHERE google_id = ?", [google_id], (err, data) => {
        if (err) return done(err);

        if (data.length > 0) {
          return done(null, data[0]); // Usuario ya registrado
        }

        db.query(
          "INSERT INTO users (email, google_id, name) VALUES (?, ?, ?)",
          [email, google_id, name],
          (err, result) => {
            if (err) return done(err);
            return done(null, { id: result.insertId, email, google_id, name });
          }
        );
      });
    }
  )
);

export default passport;

import passport from "../middleware/googleAuth.js";
import jwt from "jsonwebtoken";
import config from "../config.js";
import express from "express";
import { register, login } from "../controllers/userController.js";
import auth from "../middleware/auth.js";
import db from "../database/db.js";

const router = express.Router();

// Inicio del login de Google
router.get("/auth/google", passport.authenticate("google", { scope: ["email", "profile"] }));

// Callback después de Google Login
router.get(
  "/auth/google/callback",
  passport.authenticate("google", { session: false }),
  (req, res) => {
    const user = req.user;
    const token = jwt.sign({ id: user.id }, config.jwtSecret);

    //Enviar token a Android
    res.json({ token });
  }
);
// GET /users/me
router.get("/me", auth, (req, res) => {
  const userId = req.userId;

  db.query("SELECT id, nombre, email, contraseña FROM usuarios WHERE id = ?", 
    [userId], 
    (err, rows) => {
      if (err) return res.status(500).json({ error: "Error de base de datos" });
      if (rows.length === 0) return res.status(404).json({ error: "Usuario no encontrado" });

      const usuario = rows[0];

      // Puedes quitar la contraseña si no quieres enviarla
      delete usuario.contraseña;

      res.json(usuario);
    }
  );
});

router.post("/register", register);
router.post("/login", login);

export default router;
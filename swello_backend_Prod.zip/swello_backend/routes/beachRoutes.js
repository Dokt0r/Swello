import express from "express";
import {
  getBeachById,
  listBeaches,
} from "../controllers/beachController.js";

const router = express.Router();

// Obtener una playa por ID
router.get("/:id", getBeachById);

// Listar playas con filtros y paginación
router.get("/", listBeaches);

export default router;

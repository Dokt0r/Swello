import dotenv from 'dotenv';
dotenv.config();

const config = {
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_NAME || 'swello_db'
  },
  jwtSecret: process.env.JWT_SECRET || 'super_secreto',
  google: {
    clientID: process.env.GOOGLE_CLIENT_ID || '',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
    callbackURL: "http://localhost:3000/api/users/auth/google/callback"
  }
};

export default config;

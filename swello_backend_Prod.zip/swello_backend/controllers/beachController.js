import beachService from "../services/beachService.js";

export const getBeachById = async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const beach = await beachService.getBeachById(id);
    if (!beach) return res.status(404).json({ error: "Playa no encontrada" });
    res.json(beach); // ahora incluye todas las imágenes y campos nuevos
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const listBeaches = async (req, res) => {
  try {
    const filters = {
      nombre: req.query.q,
      lat: req.query.lat ? parseFloat(req.query.lat) : null,
      lon: req.query.lon ? parseFloat(req.query.lon) : null,
      distanciaMin: req.query.distanciaMin ? parseFloat(req.query.distanciaMin) : null,
      distanciaMax: req.query.distanciaMax ? parseFloat(req.query.distanciaMax) : null,
      olaMin: req.query.olaMin ? parseFloat(req.query.olaMin) : null,
      olaMax: req.query.olaMax ? parseFloat(req.query.olaMax) : null,
      direccion: req.query.direccion || null,
      tempAguaMin: req.query.tempAguaMin || null,
      tempAguaMax: req.query.tempAguaMax || null,
      sort: req.query.sort || null,
      limit: req.query.limit ? parseInt(req.query.limit) : 10,
      offset: req.query.offset ? parseInt(req.query.offset) : 0,
    };

    const beaches = await beachService.listBeaches(filters);
    res.json(beaches);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

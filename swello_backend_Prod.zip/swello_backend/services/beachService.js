import db from "../database/db.js";

/* ============================================================
   Obtener playa por ID
   ============================================================ */
const getBeachById = (id) => {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT 
        p.id,
        p.nombre,
        p.descripcion,
        p.valoracion,
        p.latitud,
        p.longitud,
        p.altura_ola,
        p.periodo_ola,
        p.direccion_ola,
        p.temp_agua,
        p.ocean_current_velocity,
        p.ocean_current_direction,
        (SELECT AVG(v.valoracion)
         FROM valoraciones v
         WHERE v.id_playa = p.id) AS valoracion_media,
        GROUP_CONCAT(i.nombre_archivo) AS imagenes
      FROM playas p
      LEFT JOIN imagenes_playa i ON i.id_playa = p.id
      WHERE p.id = ?
      GROUP BY p.id
      LIMIT 1
    `;

    db.query(sql, [id], (err, results) => {
      if (err) return reject(err);

      const row = results[0] || null;
      if (!row) return resolve(null);

      if (row.imagenes) {
        row.imagenes = row.imagenes.split(",").map(img =>
          `http://localhost:3000/uploads/${img}`
        );
      } else row.imagenes = [];

      resolve(row);
    });
  });
};

/* ============================================================
   Listado de playas — Filtrado + distancia real (Haversine)
   ============================================================ */
const listBeaches = (filters) => {
  return new Promise((resolve, reject) => {
    const lat = filters.lat || 0;
    const lon = filters.lon || 0;

    let sql = `
      SELECT 
        p.id,
        p.nombre,
        p.valoracion,
        p.latitud,
        p.longitud,
        p.altura_ola,
        p.direccion_ola,
        p.temp_agua,
        (SELECT i.nombre_archivo 
         FROM imagenes_playa i 
         WHERE i.id_playa = p.id 
         LIMIT 1) AS imagen_principal,
        (
          6371 * acos(
            cos(radians(?)) 
            * cos(radians(p.latitud)) 
            * cos(radians(p.longitud) - radians(?)) 
            + sin(radians(?)) 
            * sin(radians(p.latitud))
          )
        ) AS distancia
      FROM playas p
    `;

    const params = [lat, lon, lat];
    const whereClauses = [];

    /* ------------ Filtros de nombre, olas, dirección ------------ */

    if (filters.nombre) {
      whereClauses.push("p.nombre LIKE ?");
      params.push(`%${filters.nombre}%`);
    }

    if (filters.olaMin != null) {
      whereClauses.push("p.altura_ola >= ?");
      params.push(filters.olaMin);
    }

    if (filters.olaMax != null) {
      whereClauses.push("p.altura_ola <= ?");
      params.push(filters.olaMax);
    }

    if (filters.direccion) {
      whereClauses.push("p.direccion_ola = ?");
      params.push(filters.direccion);
    }

    /* ------------ NUEVO: FILTRO DE TEMPERATURA DEL AGUA ------------ */

    if (filters.tempAguaMin != null) {
      whereClauses.push("p.temp_agua >= ?");
      params.push(filters.tempAguaMin);
    }

    if (filters.tempAguaMax != null) {
      whereClauses.push("p.temp_agua <= ?");
      params.push(filters.tempAguaMax);
    }

    /* ------------ Filtros de distancia con Haversine ------------ */

    if (filters.distanciaMin != null) {
      whereClauses.push(`
        (6371 * acos(
          cos(radians(?)) 
          * cos(radians(p.latitud)) 
          * cos(radians(p.longitud) - radians(?)) 
          + sin(radians(?)) 
          * sin(radians(p.latitud))
        )) >= ?
      `);
      params.push(lat, lon, lat, filters.distanciaMin);
    }

    if (filters.distanciaMax != null) {
      whereClauses.push(`
        (6371 * acos(
          cos(radians(?)) 
          * cos(radians(p.latitud)) 
          * cos(radians(p.longitud) - radians(?)) 
          + sin(radians(?)) 
          * sin(radians(p.latitud))
        )) <= ?
      `);
      params.push(lat, lon, lat, filters.distanciaMax);
    }

    /* ------------ Aplicar WHERE si hay filtros ------------ */

    if (whereClauses.length > 0) {
      sql += " WHERE " + whereClauses.join(" AND ");
    }

    /* ------------ Ordenación ------------ */

    if (filters.lat && filters.lon) {
      sql += " ORDER BY distancia ASC";
    } else if (filters.sort === "valoracion") {
      sql += " ORDER BY valoracion_media DESC";
    } else {
      sql += " ORDER BY p.nombre ASC";
    }

    sql += " LIMIT ? OFFSET ?";
    params.push(filters.limit || 10, filters.offset || 0);

    db.query(sql, params, (err, results) => {
      if (err) return reject(err);

      results.forEach(row => {
        if (row.imagen_principal) {
          row.imagen_principal = `http://10.0.2.2:3000/uploads/${row.imagen_principal}`;
        }
      });

      resolve(results);
    });
  });
};

export default { getBeachById, listBeaches };

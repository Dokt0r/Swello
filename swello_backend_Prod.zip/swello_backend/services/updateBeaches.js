// updateBeaches.js
import db from "./../database/db.js";
import { fetchWeatherApi } from "openmeteo";

/* =======================================================
   Convertir grados → dirección cardinal
   ======================================================= */
function gradosACardinal(deg) {
    if (deg === null || deg === undefined) return null;

    const dirs = [
        "N",  "NNE", "NE",  "ENE",
        "E",  "ESE", "SE",  "SSE",
        "S",  "SSW", "SW",  "WSW",
        "W",  "WNW", "NW",  "NNW"
    ];

    const index = Math.round(deg / 22.5) % 16;
    return dirs[index];
}

/* =======================================================
   Redondear a 2 decimales de forma segura
   ======================================================= */
function round2(n) {
    return n === null || n === undefined ? null : Number(n.toFixed(2));
}

/* =======================================================
   ACTUALIZAR TODAS LAS PLAYAS
   ======================================================= */
export async function updateBeachesFromMarineWeather() {
    try {
        console.log("[INFO] Iniciando actualización de playas...");

        // Obtener playas
        const [playas] = await db.promise().query("SELECT * FROM playas");

        console.log(`[INFO] Recuperadas ${playas.length} playas.`);

        for (const playa of playas) {
            console.log(
                `[INFO] Procesando playa ID ${playa.id} (lat=${playa.latitud}, lon=${playa.longitud})`
            );

            try {
                const params = {
                    latitude: playa.latitud,
                    longitude: playa.longitud,
                    current: [
                        "wave_height",
                        "wave_direction",
                        "wave_period",
                        "sea_surface_temperature",
                        "ocean_current_velocity",
                        "ocean_current_direction"
                    ],
                    forecast_days: 1
                };

                const url = "https://marine-api.open-meteo.com/v1/marine";
                const responses = await fetchWeatherApi(url, params);
                const response = responses[0];
                const current = response.current();

                // Extraer datos
                const alturaOla = round2(current.variables(0).value());
                const direccionOlaGrados = current.variables(1).value();
                const direccionOla = gradosACardinal(direccionOlaGrados);

                const periodoOla = round2(current.variables(2).value());
                const tempAgua = round2(current.variables(3).value());
                const currentVelocity = round2(current.variables(4).value());
                const corrienteGrados = current.variables(5).value();
                const currentDirection = gradosACardinal(corrienteGrados);

                console.log("[DEBUG] Datos:", {
                    alturaOla,
                    direccionOla,
                    periodoOla,
                    tempAgua,
                    currentVelocity,
                    currentDirection
                });

                // Actualización SQL
                const sql = `
                    UPDATE playas SET
                        altura_ola = ?,
                        periodo_ola = ?,
                        direccion_ola = ?,
                        temp_agua = ?,
                        ocean_current_velocity = ?,
                        ocean_current_direction = ?
                    WHERE id = ?
                `;

                const values = [
                    alturaOla,
                    periodoOla,
                    direccionOla,
                    tempAgua,
                    currentVelocity,
                    currentDirection,
                    playa.id
                ];

                const [result] = await db.promise().query(sql, values);

                console.log(
                    `[INFO] Playa ${playa.id} actualizada. Filas modificadas: ${result.affectedRows}`
                );

            } catch (err) {
                console.error(
                    `[ERROR] Error procesando playa ID ${playa.id}:`,
                    err.message
                );
            }
        }

        console.log("[INFO] Actualización completa.");
    } catch (err) {
        console.error("[ERROR] Error general al actualizar playas:", err.message);
    }
}

// Ejecutar automáticamente cada 30 minutos
setInterval(updateBeachesFromMarineWeather, 30 * 60 * 1000);

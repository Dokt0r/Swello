import db from "../database/db.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import config from "../config.js";

const registerUser = ({ nombre, email, password, fecha_nacimiento  }) => {
  return new Promise((resolve, reject) => {

    // Validación de campos
    if (!nombre || !email || !password || !fecha_nacimiento ) {
      console.log("campos");
      return reject({ status: 400, message: "Todos los campos son obligatorios" });
    }

    // Comprobar duplicados
    db.query(
      "SELECT * FROM usuarios WHERE nombre = ? OR email = ?",
      [nombre, email],
      async (err, results) => {
        if (err) return reject({ status: 500, message: "Error en la base de datos" });
        if (results.length > 0) {return reject({ status: 400, message: "El nombre o email ya está registrado" });}

        try {
          const hashedPass = await bcrypt.hash(password, 10);

          db.query(
            "INSERT INTO usuarios (nombre, email, contraseña, fecha_nacimiento) VALUES (?, ?, ?, ?)",
            [nombre, email, hashedPass, fecha_nacimiento ],
            (err2, result) => {

              if (err2) return reject({ status: 500, message: "Error registrando usuario" });
              resolve({ status: 201, message: "Usuario registrado con éxito" });
            }
          );
        } catch (e) {
          reject({ status: 500, message: "Error inesperado: " + e.message });
        }
      }
    );
  });
};

const loginUser = async ({ email, password }) => {
  return new Promise((resolve, reject) => {
    db.query("SELECT * FROM usuarios WHERE nombre = ? OR email = ?", [email,email], async (err, data) => {
      if (err) return reject(err);
      if (data.length === 0) return reject(new Error("Usuario no encontrado"));

      const user = data[0];
      if (!user.contraseña)
        return reject(new Error("Este usuario solo puede iniciar con Google"));

      //const passOK = await bcrypt.compare(password, user.password);
      const hasspassOK = await bcrypt.compare(password, user.contraseña);
      const passOK = password == user.contraseña || hasspassOK;
      //const passOK = true;
      if (!passOK) return reject(new Error("Contraseña incorrecta"));

      const token = jwt.sign({ id: user.id }, config.jwtSecret);
      resolve({ token });
    });
  });
};


export default { registerUser, loginUser };

import express from "express";
import cors from "cors";
import morgan from "morgan";
import userRoutes from "./routes/userRoutes.js";
import beachRoutes from "./routes/beachRoutes.js";
import db from "./database/db.js"; // Conexión a DB
import passport from "./middleware/googleAuth.js";
import path from "path";
import { fileURLToPath } from "url";
import { updateBeachesFromMarineWeather } from "./services/updateBeaches.js";

// --- Configurar __dirname en ES Modules ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// --- Middlewares ---
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));
app.use(passport.initialize());

// --- Rutas ---
app.get("/", (req, res) => res.json({ message: "API funcionando" }));
app.use("/api/users", userRoutes);
app.use("/api/beaches", beachRoutes);
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// --- Conexión a DB ---
db.getConnection((err) => {
  if (err) {
    console.error("Error conectando a swello_db:", err.message);
  } else {
    console.log("Conectado a swello_db");
  }
});

// --- Manejo global de errores ---
app.use((err, req, res, next) => {
  console.error("ERROR GLOBAL:", err);
  res.status(500).json({ error: "Error interno del servidor" });
});

// --- Inicialización del servidor ---
const PORT = process.env.PORT || 3000;
app.listen(PORT, async () => {
  console.log(`Servidor iniciado en http://localhost:${PORT}`);

  // Actualización inicial al arrancar
  try {
    console.log("Actualizando playas al iniciar el servidor...");
    await updateBeachesFromMarineWeather();
    console.log("Actualización inicial completada.");
  } catch (err) {
    console.error("Error en actualización inicial:", err.message);
  }

  // Actualización automática cada 30 minutos
  setInterval(async () => {
    console.log("Iniciando actualización automática de playas...");
    try {
      await updateBeachesFromMarineWeather();
      console.log("Actualización automática completada.");
    } catch (err) {
      console.error("Error en actualización automática:", err.message);
    }
  }, 30 * 60 * 1000);
});
